import pygame
import random
import os
from pygame import mixer
import sys

# Initialize pygame and mixer
mixer.init()
pygame.init()

# Game window dimensions
SCREEN_WIDTH = 400
SCREEN_HEIGHT = 600

# Create game window
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Jumpy')

# Set frame rate
clock = pygame.time.Clock()
FPS = 60

# Load music and sounds
pygame.mixer.music.load('assets/music.mp3')
pygame.mixer.music.set_volume(0.6)
pygame.mixer.music.play(-1, 0.0)
jump_fx = pygame.mixer.Sound('assets/jump.mp3')
jump_fx.set_volume(0.5)
death_fx = pygame.mixer.Sound('assets/death.mp3')
death_fx.set_volume(0.5)

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
PANEL = (153, 217, 234)
BUTTON_COLOR = (0, 0, 128)
BUTTON_HOVER_COLOR = (0, 102, 204)

# Define fonts
font_small = pygame.font.SysFont('Darling Coffee', 20)
font_big = pygame.font.SysFont('Dacherry', 24)

# Load images
jumpy_image = pygame.image.load('assets/jump.png').convert_alpha()
bg_image = pygame.image.load('assets/bg.png').convert_alpha()
platform_image = pygame.image.load('assets/wood.png').convert_alpha()

# Load main menu background image
menu_bg_image = pygame.image.load('assets/BG___.jpg').convert_alpha()

# Game variables (default values for medium level)
GRAVITY = 1
MAX_PLATFORMS = 10
SCROLL_THRESH = 200
platform_speed = 2
game_over = False
score = 0
lives = 3
bg_scroll = 0
start_height = 0  # To keep track of the height climbed

# Difficulty selection flag
difficulty_selected = False
difficulty = None

# Load high score
if os.path.exists('score.txt'):
    with open('score.txt', 'r') as file:
        high_score = int(file.read())
else:
    high_score = 0

# Function for outputting text onto the screen
def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))

# Function for drawing info panel
def draw_panel():
    pygame.draw.rect(screen, PANEL, (0, 0, SCREEN_WIDTH, 30))
    pygame.draw.line(screen, WHITE, (0, 30), (SCREEN_WIDTH, 30), 2)
    draw_text(f'SCORE: {score}', font_small, BLACK, 0, 0)
    draw_text(f'LIVES: {lives}', font_small, BLACK, SCREEN_WIDTH - 100, 0)

# Function for drawing the background
def draw_bg(bg_scroll):
    screen.blit(bg_image, (0, 0 + bg_scroll))
    screen.blit(bg_image, (0, -600 + bg_scroll))

# Function for drawing buttons
def draw_button(text, font, text_col, button_col, x, y, width, height):
    pygame.draw.rect(screen, button_col, (x, y, width, height))
    pygame.draw.rect(screen, WHITE, (x, y, width, height), 2)  # Border
    text_img = font.render(text, True, text_col)
    screen.blit(text_img, (x + (width - text_img.get_width()) // 2, y + (height - text_img.get_height()) // 2))

# Difficulty menu function with buttons
def difficulty_menu():
    global difficulty_selected, difficulty, GRAVITY, MAX_PLATFORMS, platform_speed

    menu_running = True
    while menu_running:
        # Draw the main menu background
        screen.blit(menu_bg_image, (0, 0))

        # Button positions and dimensions
        button_width = 200
        button_height = 50
        easy_button = pygame.Rect((SCREEN_WIDTH - button_width) // 2, 260, button_width, button_height)
        medium_button = pygame.Rect((SCREEN_WIDTH - button_width) // 2, 330, button_width, button_height)
        hard_button = pygame.Rect((SCREEN_WIDTH - button_width) // 2, 400, button_width, button_height)

        # Get mouse position
        mouse_pos = pygame.mouse.get_pos()

        # Draw difficulty buttons and change color on hover
        if easy_button.collidepoint(mouse_pos):
            draw_button('EASY', font_big, WHITE, BUTTON_HOVER_COLOR, easy_button.x, easy_button.y, easy_button.width, easy_button.height)
        else:
            draw_button('EASY', font_big, WHITE, BUTTON_COLOR, easy_button.x, easy_button.y, easy_button.width, easy_button.height)

        if medium_button.collidepoint(mouse_pos):
            draw_button('MEDIUM', font_big, WHITE, BUTTON_HOVER_COLOR, medium_button.x, medium_button.y, medium_button.width, medium_button.height)
        else:
            draw_button('MEDIUM', font_big, WHITE, BUTTON_COLOR, medium_button.x, medium_button.y, medium_button.width, medium_button.height)

        if hard_button.collidepoint(mouse_pos):
            draw_button('HARD', font_big, WHITE, BUTTON_HOVER_COLOR, hard_button.x, hard_button.y, hard_button.width, hard_button.height)
        else:
            draw_button('HARD', font_big, WHITE, BUTTON_COLOR, hard_button.x, hard_button.y, hard_button.width, hard_button.height)

        # Check for user input
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if easy_button.collidepoint(mouse_pos):
                    difficulty_selected = True
                    difficulty = 'easy'
                    GRAVITY = 0.7
                    MAX_PLATFORMS = 12
                    platform_speed = 1
                    menu_running = False
                elif medium_button.collidepoint(mouse_pos):
                    difficulty_selected = True
                    difficulty = 'medium'
                    GRAVITY = 1
                    MAX_PLATFORMS = 10
                    platform_speed = 2
                    menu_running = False
                elif hard_button.collidepoint(mouse_pos):
                    difficulty_selected = True
                    difficulty = 'hard'
                    GRAVITY = 1.3
                    MAX_PLATFORMS = 8
                    platform_speed = 3
                    menu_running = False

        # Update the display
        pygame.display.update()
        clock.tick(FPS)

# Player class
class Player:
    def __init__(self, x, y):
        self.image = pygame.transform.scale(jumpy_image, (45, 45))
        self.width = 25
        self.height = 40
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.center = (x, y)
        self.vel_y = 0
        self.flip = False
        self.start_height = y  # Track the starting height for scoring

    def move(self):
        scroll = 0
        dx = 0
        dy = 0

        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT]:
            dx = -10
            self.flip = True
        if key[pygame.K_RIGHT]:
            dx = 10
            self.flip = False

        self.vel_y += GRAVITY
        dy += self.vel_y

        if self.rect.left + dx < 0:
            dx = -self.rect.left
        if self.rect.right + dx > SCREEN_WIDTH:
            dx = SCREEN_WIDTH - self.rect.right

        for platform in platform_group:
            if platform.rect.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                if self.rect.bottom < platform.rect.centery:
                    if self.vel_y > 0:
                        self.rect.bottom = platform.rect.top
                        dy = 0
                        self.vel_y = -20
                        jump_fx.play()

        if self.rect.top <= SCROLL_THRESH:
            if self.vel_y < 0:
                scroll = -dy

        self.rect.x += dx
        self.rect.y += dy + scroll

        self.mask = pygame.mask.from_surface(self.image)

        return scroll

    def draw(self):
        screen.blit(pygame.transform.flip(self.image, self.flip, False), (self.rect.x - 12, self.rect.y - 5))

    def update_score(self):
        global score
        # Update score as player climbs up
        if self.rect.top < self.start_height:
            score += (self.start_height - self.rect.top) // 10  # Increase score for every 10 pixels climbed
            self.start_height = self.rect.top  # Reset height tracking

# Platform class
class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width, moving):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(platform_image, (width, 10))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.moving = moving
        self.move_counter = random.randint(0, 50)
        self.direction = random.choice([-1, 1])

    def update(self, scroll):
        if self.moving:
            self.move_counter += 1
            self.rect.x += self.direction * platform_speed
            if self.move_counter >= 100 or self.rect.left < 0 or self.rect.right > SCREEN_WIDTH:
                self.direction *= -1
                self.move_counter = 0

        self.rect.y += scroll

        if self.rect.top > SCREEN_HEIGHT:
            self.kill()

# Player instance
jumpy = Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 150)

# Create sprite groups
platform_group = pygame.sprite.Group()

# Create starting platform
platform = Platform(SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT - 50, 100, False)
platform_group.add(platform)

# Call the difficulty menu before starting the game loop
difficulty_menu()

# Game loop
run = True
while run:
    clock.tick(FPS)

    if not game_over:
        # Player movement and scrolling
        scroll = jumpy.move()

        # Update the score based on the player's height
        jumpy.update_score()

        # Draw background
        bg_scroll += scroll
        if bg_scroll >= 600:
            bg_scroll = 0
        draw_bg(bg_scroll)

        # Generate platforms
        if len(platform_group) < MAX_PLATFORMS:
            p_w = random.randint(40, 60)
            p_x = random.randint(0, SCREEN_WIDTH - p_w)
            p_y = platform.rect.y - random.randint(80, 120)
            p_moving = difficulty == 'hard' or (difficulty == 'medium' and random.choice([True, False]))
            platform = Platform(p_x, p_y, p_w, p_moving)
            platform_group.add(platform)

        # Update platforms
        platform_group.update(scroll)

        # Draw sprites
        platform_group.draw(screen)
        jumpy.draw()

        # Draw panel
        draw_panel()

        # Check game over condition
        if jumpy.rect.top > SCREEN_HEIGHT:
            lives -= 1
            if lives <= 0:
                game_over = True
                death_fx.play()
            else:
                # Reset position
                scroll = 0
                jumpy.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 150)
                platform_group.empty()
                platform = Platform(SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT - 50, 100, False)
                platform_group.add(platform)
                pygame.time.delay(1000)

    else:
        # Game over screen
        draw_text('GAME OVER!', font_big, WHITE, 130, 200)
        draw_text('SCORE: ' + str(score), font_big, WHITE, 130, 250)
        draw_text('PRESS SPACE TO PLAY AGAIN', font_big, WHITE, 40, 300)
        key = pygame.key.get_pressed()
        if key[pygame.K_SPACE]:
            # Reset variables
            game_over = False
            lives = 3
            score = 0
            jumpy.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 150)
            platform_group.empty()
            platform = Platform(SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT - 50, 100, False)
            platform_group.add(platform)
            difficulty_menu()

    # Event handler
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # Update display window
    pygame.display.update()

pygame.quit()
