import pygame
import random
import os
import sys
from pygame import mixer

# Initialize pygame and mixer
mixer.init()
pygame.init()

# Game window dimensions
SCREEN_WIDTH = 400
SCREEN_HEIGHT = 600

# Create game window
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Jumpy')

# Set frame rate
clock = pygame.time.Clock()
FPS = 60

# Load music and sounds
pygame.mixer.music.load('assets/music.mp3')
pygame.mixer.music.set_volume(0.6)
pygame.mixer.music.play(-1, 0.0)
jump_fx = pygame.mixer.Sound('assets/jump.mp3')
jump_fx.set_volume(0.5)
death_fx = pygame.mixer.Sound('assets/death.mp3')
death_fx.set_volume(0.5)

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
PANEL = (153, 217, 234)
BUTTON_COLOR = (0, 0, 128)
BUTTON_HOVER_COLOR = (0, 102, 204)

# Define fonts
font_small = pygame.font.SysFont('Darling Coffee', 20)
font_big = pygame.font.SysFont('Dacherry', 24)

# Load images
jumpy_image = pygame.image.load('assets/jump.png').convert_alpha()
bg_image = pygame.image.load('assets/bg.png').convert_alpha()
platform_image = pygame.image.load('assets/wood.png').convert_alpha()
bird_image = pygame.image.load('assets/bird.png').convert_alpha()
menu_bg_image = pygame.image.load('assets/BG___.jpg').convert_alpha()

# Game variables
GRAVITY = 1
MAX_PLATFORMS = 10
SCROLL_THRESH = 200
platform_speed = 2
game_over = False
score = 0
lives = 3
bg_scroll = 0
start_height = 0
difficulty_selected = False
difficulty = None

# Load high score
if os.path.exists('score.txt'):
    with open('score.txt', 'r') as file:
        high_score = int(file.read())
else:
    high_score = 0

# Function for outputting text onto the screen
def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))

# Function for drawing info panel
def draw_panel():
    pygame.draw.rect(screen, PANEL, (0, 0, SCREEN_WIDTH, 30))
    pygame.draw.line(screen, WHITE, (0, 30), (SCREEN_WIDTH, 30), 2)
    draw_text(f'SCORE: {score}', font_small, BLACK, 0, 0)
    draw_text(f'LIVES: {lives}', font_small, BLACK, SCREEN_WIDTH - 100, 0)

# Function for drawing the background
def draw_bg(bg_scroll):
    screen.blit(bg_image, (0, 0 + bg_scroll))
    screen.blit(bg_image, (0, -600 + bg_scroll))

# Function for drawing buttons
def draw_button(text, font, text_col, button_col, x, y, width, height):
    pygame.draw.rect(screen, button_col, (x, y, width, height))
    pygame.draw.rect(screen, WHITE, (x, y, width, height), 2)  # Border
    text_img = font.render(text, True, text_col)
    screen.blit(text_img, (x + (width - text_img.get_width()) // 2, y + (height - text_img.get_height()) // 2))

# Difficulty menu function with buttons
def difficulty_menu():
    global difficulty_selected, difficulty, GRAVITY, MAX_PLATFORMS, platform_speed, lives

    menu_running = True
    while menu_running:
        screen.blit(menu_bg_image, (0, 0))

        button_width = 200
        button_height = 50
        easy_button = pygame.Rect((SCREEN_WIDTH - button_width) // 2, 260, button_width, button_height)
        medium_button = pygame.Rect((SCREEN_WIDTH - button_width) // 2, 330, button_width, button_height)
        hard_button = pygame.Rect((SCREEN_WIDTH - button_width) // 2, 400, button_width, button_height)

        mouse_pos = pygame.mouse.get_pos()

        if easy_button.collidepoint(mouse_pos):
            draw_button('EASY', font_big, WHITE, BUTTON_HOVER_COLOR, easy_button.x, easy_button.y, easy_button.width, easy_button.height)
        else:
            draw_button('EASY', font_big, WHITE, BUTTON_COLOR, easy_button.x, easy_button.y, easy_button.width, easy_button.height)

        if medium_button.collidepoint(mouse_pos):
            draw_button('MEDIUM', font_big, WHITE, BUTTON_HOVER_COLOR, medium_button.x, medium_button.y, medium_button.width, medium_button.height)
        else:
            draw_button('MEDIUM', font_big, WHITE, BUTTON_COLOR, medium_button.x, medium_button.y, medium_button.width, medium_button.height)

        if hard_button.collidepoint(mouse_pos):
            draw_button('HARD', font_big, WHITE, BUTTON_HOVER_COLOR, hard_button.x, hard_button.y, hard_button.width, hard_button.height)
        else:
            draw_button('HARD', font_big, WHITE, BUTTON_COLOR, hard_button.x, hard_button.y, hard_button.width, hard_button.height)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if easy_button.collidepoint(mouse_pos):
                    difficulty_selected = True
                    difficulty = 'easy'
                    GRAVITY = 0.7
                    MAX_PLATFORMS = 12
                    platform_speed = 0
                    lives = 3
                    menu_running = False
                elif medium_button.collidepoint(mouse_pos):
                    difficulty_selected = True
                    difficulty = 'medium'
                    GRAVITY = 1
                    MAX_PLATFORMS = 10
                    platform_speed = 2
                    lives = 3
                    menu_running = False
                elif hard_button.collidepoint(mouse_pos):
                    difficulty_selected = True
                    difficulty = 'hard'
                    GRAVITY = 1.3
                    MAX_PLATFORMS = 8
                    platform_speed = 4
                    lives = 2  # Reduced lives in hard mode
                    menu_running = False

        pygame.display.update()
        clock.tick(FPS)

# Player class
class Player:
    def __init__(self, x, y):
        self.image = pygame.transform.scale(jumpy_image, (45, 45))
        self.width = 25
        self.height = 40
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.center = (x, y)
        self.vel_y = 0
        self.flip = False
        self.jump_count = 0

    def move(self):
        scroll = 0
        dx = 0
        dy = 0

        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT]:
            dx = -10
            self.flip = True
        if key[pygame.K_RIGHT]:
            dx = 10
            self.flip = False
        if key[pygame.K_SPACE]:
            if self.jump_count < 2:
                self.vel_y = -20
                self.jump_count += 1
                jump_fx.play()
        
        self.vel_y += GRAVITY
        dy += self.vel_y

        if self.rect.left + dx < 0:
            dx = -self.rect.left
        if self.rect.right + dx > SCREEN_WIDTH:
            dx = SCREEN_WIDTH - self.rect.right

        for platform in platform_group:
            if platform.rect.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                if self.rect.bottom < platform.rect.centery:
                    if self.vel_y > 0:
                        self.rect.bottom = platform.rect.top
                        dy = 0
                        self.vel_y = -20
                        jump_fx.play()
                        self.jump_count = 1
                        increase_score()

        if self.rect.top <= SCROLL_THRESH:
            if self.vel_y < 0:
                scroll = -dy

        self.rect.x += dx
        self.rect.y += dy + scroll

        self.mask = pygame.mask.from_surface(self.image)

        return scroll

    def draw(self):
        screen.blit(pygame.transform.flip(self.image, self.flip, False), (self.rect.x - 12, self.rect.y - 5))

# Function to increase score on jump
def increase_score():
    global score
    score += 10

# Platform class
class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width, moving):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(platform_image, (width, 20))
        self.rect = self.image.get_rect(topleft=(x, y))
        self.moving = moving
        self.move_counter = random.randint(0, 50)
        self.direction = random.choice([-1, 1])

    def update(self, scroll):
        if self.moving:
            self.move_counter += 1
            self.rect.x += self.direction * platform_speed
            if self.move_counter >= 100 or self.rect.left < 0 or self.rect.right > SCREEN_WIDTH:
                self.direction *= -1
                self.move_counter = 0

        self.rect.y += scroll
        if self.rect.top > SCREEN_HEIGHT:
            self.kill()

# Bird class
class Bird(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(bird_image, (50, 45))
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = random.randint(4, 6)  # Increased bird speed for hard mode

    def update(self, scroll):
        self.rect.x += self.speed
        self.rect.y += scroll

        if self.rect.left > SCREEN_WIDTH or self.rect.right < 0:
            self.kill()

# Create sprite groups
platform_group = pygame.sprite.Group()
bird_group = pygame.sprite.Group()

# Create the player
jumpy = Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 150)

# Create starting platforms
platform = Platform(SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT - 50, 100, False)
platform_group.add(platform)

# Game loop
running = True
while running:

    clock.tick(FPS)

    if not difficulty_selected:
        difficulty_menu()

    else:
        scroll = jumpy.move()

        bg_scroll += scroll
        if bg_scroll >= 600:
            bg_scroll = 0

        draw_bg(bg_scroll)

        if len(platform_group) < MAX_PLATFORMS:
            p_w = random.randint(40, 60)
            p_x = random.randint(0, SCREEN_WIDTH - p_w)
            p_y = platform.rect.y - random.randint(80, 120)
            platform_group.add(Platform(p_x, p_y, p_w, random.choice([True, False])))

        platform_group.update(scroll)

        if len(bird_group) < 5 and random.random() < 0.05:  # Increased frequency and limit for hard mode
            bird = Bird(random.choice([-40, SCREEN_WIDTH]), random.randint(50, 300))
            bird_group.add(bird)

        bird_group.update(scroll)

        platform_group.draw(screen)
        bird_group.draw(screen)

        jumpy.draw()

        draw_panel()

        if pygame.sprite.spritecollide(jumpy, bird_group, False, pygame.sprite.collide_mask):
            lives -= 2  # Lose two lives when hit by a bird in hard mode
            death_fx.play()
            pygame.time.delay(500)
            game_over = lives <= 0

        if game_over:
            draw_text('GAME OVER!', font_big, BLACK, SCREEN_WIDTH // 2 - 80, SCREEN_HEIGHT // 2)
            pygame.display.update()
            pygame.time.delay(2000)
            running = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

    pygame.display.update()

pygame.quit()
